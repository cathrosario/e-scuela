# e-scuela Prototype — Red School Theme
Team: Souljah Bai
Brand: e-scuela
School: Escuela de Nuestra Señora de la Salette

This version follows the uploaded reference: deep-red sidebar, white rounded content cards,
red headings/borders/buttons, spacious two-column forms, and a clean school-admin dashboard.

Demo login:
Username: admin
Password: admin123

Open index.html in a browser.
